class Beer < ApplicationRecord

  belongs_to :brewery
  # , :foreign_key => :location


end
